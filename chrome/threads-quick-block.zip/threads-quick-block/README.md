# Threads Quick Block

Extension Chrome pour bloquer, mettre en sourdine ou signaler plus vite sur Threads (version web).

## Installation

1. Décompresse le zip.
2. Ouvre `chrome://extensions`, active le **Mode développeur** (en haut à droite).
3. Clique **Charger l'extension non empaquetée** et choisis le dossier `threads-quick-block`.
4. Recharge l'onglet Threads.

Pour une mise à jour : remplace le dossier, puis clique ↻ sur l'extension dans `chrome://extensions` et recharge Threads.

## Utilisation

Sur la ligne du pseudo de chaque post :

- **💬 Répondre** : publie en réponse une phrase tirée au hasard dans ta liste (popup). Une seule réponse par post via l'extension. Varie tes phrases : des réponses identiques en série peuvent être vues comme du spam.

- **⛔ Bloquer** : Threads ne propose « Bloquer » que sur la page de profil. L'extension ouvre donc le profil, bloque, puis revient au fil.
- **🔇 Mettre en sourdine** : même principe avec « Mettre en sourdine ».
- **⚡ Tout enchaîner** : signale le post comme faux compte, puis ouvre le profil pour mettre en sourdine et bloquer, et revient au fil. Les étapes déjà faites pour ce compte sont sautées. Si le signalement doit être fini à la main, la chaîne s'arrête : termine-le puis reclique ⚡ pour la suite.
- **🚩 Signaler comme faux compte** : ouvre « Signaler », choisit « Bot ou faux compte » (et le sous-motif correspondant s'il y en a un), puis envoie. Si un écran ne correspond à rien de connu, l'extension s'arrête et te laisse finir à la main (toast rouge).

Les mêmes boutons apparaissent dans une barre flottante en bas à droite sur une page de profil.

**Mots-clés** (icône de l'extension) : les posts dont le pseudo, le nom ou le texte contient un de tes mots-clés sont marqués d'une barre rouge et d'une étiquette. Rien n'est fait automatiquement.

Les posts de comptes bloqués sont grisés, ceux en sourdine atténués (uniquement pour les actions faites via l'extension).

Chaque bouton peut être masqué dans le popup.

## Garde-fous

- 3 à 4 s minimum entre deux actions (file d'attente si tu cliques vite).
- Alerte au-delà d'un nombre d'actions par heure réglable dans le popup (40 par défaut, 0 = aucune). Meta ne publie pas de seuil officiel : c'est un garde-fou arbitraire.
- La case « Demander confirmation » du popup s'applique à toutes les actions (désactivée par défaut).

## Si ça ne marche plus

Threads change régulièrement son interface. En cas de toast d'erreur, ajuste dans `content.js` :

- `MORE_LABELS` (bouton « … ») et `ACTIONS[...].menu` (libellés du menu) ;
- pour le signalement : `FAKE_PATTERNS`, `PARENT_PATTERNS`, `SUBMIT_WORDS`.
