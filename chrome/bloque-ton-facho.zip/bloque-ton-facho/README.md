# Bloque ton facho

Une extension pour Google Chrome qui ajoute de petits boutons sur Threads pour bloquer, mettre en sourdine, signaler ou répondre en un seul clic.

## Installation

1. Télécharge le fichier `.zip` de l'extension et décompresse-le (double-clic dessus). Tu obtiens un dossier `bloque-ton-facho`.
2. Range ce dossier à un endroit où tu ne le supprimeras pas (par exemple dans Documents) : Chrome en a besoin en permanence.
3. Dans Chrome, tape `chrome://extensions` dans la barre d'adresse et appuie sur Entrée.
4. En haut à droite, active **Mode développeur**.
5. Clique sur **Charger l'extension non empaquetée** et sélectionne le dossier `bloque-ton-facho`.
6. Ouvre (ou recharge) Threads sur threads.com : les boutons apparaissent à côté du nom de chaque personne.

Astuce : clique sur l'icône en forme de pièce de puzzle en haut à droite de Chrome, puis sur l'épingle à côté de Bloque ton facho pour garder son icône visible.

### Mettre à jour

Remplace l'ancien dossier par le nouveau, retourne sur `chrome://extensions`, clique sur la flèche ↻ de l'extension, puis recharge Threads.

## Utilisation

À côté du nom de la personne, sur chaque post :

- **💬 Répondre** : publie en réponse une de tes phrases, tirée au hasard.
- **⚡ Tout faire** : signale le compte comme faux compte, le met en sourdine, puis le bloque.
- **⛔ Bloquer** : bloque le compte.
- **🔇 Sourdine** : met le compte en sourdine.
- **🚩 Signaler** : signale le compte comme « Bot ou faux compte ».

Sur la page d'un profil, les mêmes boutons apparaissent aussi en bas à droite de l'écran.

Un petit message en bas de l'écran confirme chaque action. Le bouton devient vert quand c'est fait.

## Réglages

Clique sur l'icône de l'extension (le bouclier rouge et blanc) pour :

- **Mots-clés** : écris des mots, hashtags ou emojis (un par ligne). Les posts qui les contiennent sont marqués d'une barre rouge, pour les repérer d'un coup d'œil. Rien n'est fait automatiquement.
- **Phrases de réponse** : écris les phrases que le bouton 💬 utilisera (une par ligne). Mets-en plusieurs et varie-les.
- **Choisir les boutons** à afficher.
- **Demander confirmation** avant chaque action, si tu préfères valider à chaque fois.
- **Alerte** au-delà d'un certain nombre d'actions par heure (0 pour ne jamais être prévenu).
- **Historique** des comptes traités, que tu peux exporter.

N'oublie pas de cliquer sur **Enregistrer** après une modification.

## Bon à savoir

- L'extension laisse quelques secondes entre deux actions, pour ne pas ressembler à un robot. Si tu cliques vite sur plusieurs comptes, elle les traite les uns après les autres.
- Elle fonctionne sur Threads dans le navigateur de l'ordinateur, pas dans l'application du téléphone.
- Si un message rouge s'affiche, Threads a peut-être changé quelque chose : fais l'action à la main pour cette fois.
